module.exports = {
    plugins: [
        require("autoprefixer")({
            browsers: ['ie>=8','>1% in CN']
        })
    ]
}